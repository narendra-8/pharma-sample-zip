<?php
define('DB_SERVER', '');
define('DB_USERNAME', '');
define('DB_PASSWORD', '');
define('DB_NAME', '');

try{
    $pdo = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
    die("ERROR: Could not connect. " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Upload</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="#">
    <meta name="keywords" content="Admin , Responsive, Landing, Bootstrap, App, Template, Mobile, iOS, Android, apple, creative app">
    <meta name="author" content="#">
    <!-- Google font--><link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="libraries\bower_components\bootstrap\css\bootstrap.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="libraries\assets\icon\font-awesome\css\font-awesome.min.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="libraries\assets\icon\themify-icons\themify-icons.css">
	<!-- ion icon css -->
    <link rel="stylesheet" type="text/css" href="libraries\assets\icon\ion-icon\css\ionicons.min.css">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="libraries\assets\icon\icofont\css\icofont.css">
    <!-- feather Awesome -->
    <link rel="stylesheet" type="text/css" href="libraries\assets\icon\feather\css\feather.css">
	<!-- Data Table Css -->
    <link rel="stylesheet" type="text/css" href="libraries\bower_components\datatables.net-bs4\css\dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="libraries\assets\pages\data-table\css\buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="libraries\bower_components\datatables.net-responsive-bs4\css\responsive.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="libraries\assets\pages\data-table\extensions\responsive\css\responsive.dataTables.css">
	
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="libraries\assets\css\style.css">
    <link rel="stylesheet" type="text/css" href="libraries\assets\css\jquery.mCustomScrollbar.css">
</head>
<body>
<!-- Pre-loader start -->
<div class="theme-loader">
    <div class="ball-scale">
        <div class='contain'>
            <div class="ring">
                <div class="frame"></div>
            </div>
            <div class="ring">
                <div class="frame"></div>
            </div>
            <div class="ring">
                <div class="frame"></div>
            </div>
            <div class="ring">
                <div class="frame"></div>
            </div>
            <div class="ring">
                <div class="frame"></div>
            </div>
            <div class="ring">
                <div class="frame"></div>
            </div>
            <div class="ring">
                <div class="frame"></div>
            </div>
            <div class="ring">
                <div class="frame"></div>
            </div>
            <div class="ring">
                <div class="frame"></div>
            </div>
            <div class="ring">
                <div class="frame"></div>
            </div>
        </div>
    </div>
</div>
<!-- Pre-loader end -->
<div id="pcoded" class="pcoded">
    <div class="pcoded-overlay-box"></div>
    <div class="pcoded-container navbar-wrapper">
		<!-- Sidebar inner chat end-->
        <div class="pcoded-main-container">
            <div class="pcoded-wrapper">
                <!-- side navigation -->
				<div class="pcoded-content">
                    <div class="pcoded-inner-content">
                        <!-- Main-body start -->
                        <div class="main-body">
                            <div class="page-wrapper">
                                <!-- Page-header start -->
                                <div class="page-header">
                                    <div class="row align-items-end">
                                        <div class="col-lg-8">
                                            <div class="page-header-title">
                                                <div class="d-inline">
                                                    <h4>Upload</h4>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="page-header-breadcrumb">
                                                <ul class="breadcrumb-title">
                                                    <li class="breadcrumb-item">
                                                        <a href="#"> <i class="feather icon-home"></i> </a>
                                                    </li>
                                                    <li class="breadcrumb-item">Upload</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Page-header end -->
								<!-- Page-body start -->
                                    <div class="page-body">
                                        <!--Card start -->
                                        <div class="card">
											<div class="card-header">
												<form class="form-horizontal" action="upload-format.php" method="post" name="upload_excel" enctype="multipart/form-data">
													<div class="row">
														<h6 class="text-c-lite-green"><b>Upload File(Only CSV)</b><span style="color:red;">*</span></h6>
														<div class="col-md-3">
															<input type="file" name="file" id="file" class="form-control form-control-sm">
														</div>
														<div class="col-md-3">
															<input type="submit" id="submit" name="upload" Value="Upload" class="btn btn-sm btn-primary button-loading" data-loading-text="Loading...">
														</div>
													</div>
												</form>
											</div>
											<div class="card-block">
                                                <div class="dt-responsive table-responsive">
                                                    <table id="res-config" class="table table-striped table-bordered nowrap">
                                                        <thead class="text-c-lite-green f-25">
                                                            <tr>
																<th>S.No</th>
                                                                <th>Name</th>
                                                                <th>Batch</th>
                                                                <th>Stock</th>
																<th>Deal</th>
                                                                <th>Free</th>
                                                                <th>MRP</th>
                                                                <th>Rate</th>
                                                                <th>Exp</th>
                                                            </tr>
                                                        </thead>
														<tbody>
                                                            <?php
																$list = "SELECT `name`,`batch`,SUM(`stock`) AS stock_sum,MIN(`deal`) AS deal,MIN(`free`) AS free,MAX(`mrp`) AS mrp,MAX(`rate`) AS rate,MAX(`exp`) AS expp FROM `reporting_list` GROUP BY `batch`";
																$stm = $pdo->prepare($list);
																$stm->execute();
																$sn = 1;
																while ($row = $stm->fetch(PDO::FETCH_ASSOC)){
																	echo '<tr>
																		<td>'.$sn.'</td>
																		<td>'.$row['name'].'</td>
																		<td>'.$row['batch'].'</td>
																		<td>'.$row['stock_sum'].'</td>
																		<td>'.$row['deal'].'</td>
																		<td>'.$row['free'].'</td>
																		<td>'.$row['mrp'].'</td>
																		<td>'.$row['rate'].'</td>
																		<td>'.$row['expp'].'</td>
																	</tr>';
																	$sn++;
																} 
															?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
										</div>
                                    </div>
                                    <!-- Page-body end -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<!-- Required Jquery -->
	<script type="text/javascript" src="libraries\bower_components\jquery\js\jquery.min.js"></script>
	<script type="text/javascript" src="libraries\bower_components\jquery-ui\js\jquery-ui.min.js"></script>
	<script type="text/javascript" src="libraries\bower_components\popper.js\js\popper.min.js"></script>
	<script type="text/javascript" src="libraries\bower_components\bootstrap\js\bootstrap.min.js"></script>
	<!-- jquery slimscroll js -->
	<script type="text/javascript" src="libraries\bower_components\jquery-slimscroll\js\jquery.slimscroll.js"></script>
    <!-- modernizr js -->
    <script type="text/javascript" src="libraries\bower_components\modernizr\js\modernizr.js"></script>
    <script type="text/javascript" src="libraries\bower_components\modernizr\js\css-scrollbars.js"></script>
	
	<!-- data-table js -->
    <script src="libraries\bower_components\datatables.net\js\jquery.dataTables.min.js"></script>
    <script src="libraries\bower_components\datatables.net-buttons\js\dataTables.buttons.min.js"></script>
    <script src="libraries\assets\pages\data-table\js\jszip.min.js"></script>
    <script src="libraries\assets\pages\data-table\js\pdfmake.min.js"></script>
    <script src="libraries\assets\pages\data-table\js\vfs_fonts.js"></script>
    <script src="libraries\assets\pages\data-table\extensions\responsive\js\dataTables.responsive.min.js"></script>
    <script src="libraries\bower_components\datatables.net-buttons\js\buttons.print.min.js"></script>
    <script src="libraries\bower_components\datatables.net-buttons\js\buttons.html5.min.js"></script>
    <script src="libraries\bower_components\datatables.net-bs4\js\dataTables.bootstrap4.min.js"></script>
    <script src="libraries\bower_components\datatables.net-responsive\js\dataTables.responsive.min.js"></script>
    <script src="libraries\bower_components\datatables.net-responsive-bs4\js\responsive.bootstrap4.min.js"></script>
    <!-- i18next.min.js -->
    <script type="text/javascript" src="libraries\bower_components\i18next\js\i18next.min.js"></script>
    <script type="text/javascript" src="libraries\bower_components\i18next-xhr-backend\js\i18nextXHRBackend.min.js"></script>
    <script type="text/javascript" src="libraries\bower_components\i18next-browser-languagedetector\js\i18nextBrowserLanguageDetector.min.js"></script>
    <script type="text/javascript" src="libraries\bower_components\jquery-i18next\js\jquery-i18next.min.js"></script>
    <!-- Custom js -->
    <script src="libraries\assets\pages\data-table\extensions\responsive\js\responsive-custom.js"></script>

    <script src="libraries\assets\js\pcoded.min.js"></script>
    <script src="libraries\assets\js\vartical-layout.min.js"></script>
    <script src="libraries\assets\js\jquery.mCustomScrollbar.concat.min.js"></script>
    <script type="text/javascript" src="libraries\assets\js\script.js"></script>
</body>
</html>
<?php
$pdo = null;
?>
