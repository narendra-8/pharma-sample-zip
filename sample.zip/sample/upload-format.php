<?php
define('DB_SERVER', '');
define('DB_USERNAME', '');
define('DB_PASSWORD', '');
define('DB_NAME', '');
try{
    $pdo = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
    die("ERROR: Could not connect. " . $e->getMessage());
}

//Upload Excel file Admin code

if(isset($_POST["upload"])){
	
	$del = "DELETE FROM `reporting_list`";
	$stm = $pdo->prepare($del);
	$stm->execute();
	
	$filename=$_FILES["file"]["tmp_name"];	
	
	if($_FILES["file"]["size"] > 0){
	  	
	  	$file = fopen($filename, "r");
		$ip = $_SERVER['REMOTE_ADDR'];
		$i = 0;
		
		while (($getData = fgetcsv($file, 10000, ",")) !== FALSE){
		    $i++;
			
			$code = $getData[0];
			$name = $getData[1];
			$batch = $getData[2];
			$stock = $getData[3];
			$deal = $getData[4];
			$free = $getData[5];
			$mrp = $getData[6];
			$rate = $getData[7];
			$expp = $getData[8];
			$company = $getData[9];
			$supplier = $getData[10];
			try{
				$insert = "INSERT INTO `reporting_list`(`code`, `name`, `batch`, `stock`, `deal`, `free`, `mrp`, `rate`, `exp`, `company`, `supplier`, `created_on`) VALUES (:code,:name,:batch,:stock,:deal,:free,:mrp,:rate,:expp,:company,:supplier,CURRENT_TIMESTAMP)";
				$stm2 = $pdo->prepare($insert);
				$stm2->bindParam(":code", $code, PDO::PARAM_STR);
				$stm2->bindParam(":name", $name, PDO::PARAM_STR);
				$stm2->bindParam(":batch", $batch, PDO::PARAM_STR);
				$stm2->bindParam(":stock", $stock, PDO::PARAM_STR);
				$stm2->bindParam(":deal", $deal, PDO::PARAM_STR);
				$stm2->bindParam(":free", $free, PDO::PARAM_STR);
				$stm2->bindParam(":mrp", $mrp, PDO::PARAM_STR);
				$stm2->bindParam(":rate", $rate, PDO::PARAM_STR);
				$stm2->bindParam(":expp", $expp, PDO::PARAM_STR);
				$stm2->bindParam(":company", $company, PDO::PARAM_STR);
				$stm2->bindParam(":supplier", $supplier, PDO::PARAM_STR);
				$stm2->execute();
			}catch (PDOException $e) {
				echo 'Connection failed: ' . $e->getMessage();
				echo 'Connection failed: ' . $e->getLine();
				exit;
			}
		}
	    if($stm2->rowCount() > 0){
            echo "<script>alert('Success!')</script>";
			
        } else {
			echo "<script>alert('Invalid File:Please Upload CSV File.')</script>";
			
		}
        fclose($file);	
    }
}
?>