"use strict";
$(document).ready(function() {
//Donut chart
	
	//Overall Count
    google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut);

    function drawChartDonut() {
        var dataDonut = google.visualization.arrayToDataTable(dataaa);

        var optionsDonut = {
            pieHole: 0.3,
            colors: ['#999999', '#00b3b3', '#8080ff', '#ff6666','#ff99c2','#ff8533']
        };

        var chart = new google.visualization.PieChart(document.getElementById('chart_Donut'));
        chart.draw(dataDonut, optionsDonut);
    }
	
	//Year count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_year);

    function drawChartDonut_year() {
        var dataDonut_year = google.visualization.arrayToDataTable(data_year);

        var optionsDonut_year = {
            pieHole: 0.3,
            colors: ['#999999', '#00b3b3', '#8080ff', '#ff6666','#ff99c2','#ff8533']
        };

        var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_year'));
        chart.draw(dataDonut_year, optionsDonut_year);
    }
	
	//Attrition count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_att);

    function drawChartDonut_att() {
        var dataDonut_att = google.visualization.arrayToDataTable(data_att);

        var optionsDonut_att = {
            pieHole: 0.3,
            colors: ['#999999', '#00b3b3', '#8080ff', '#ff6666','#ff99c2','#ff8533']
        };

        var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_att'));
        chart.draw(dataDonut_att, optionsDonut_att);
    }
	
	//Cost
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_cost);

    function drawChartDonut_cost() {
        var dataDonut_cost = google.visualization.arrayToDataTable(data_cost);

        var optionsDonut_cost = {
            pieHole: 0.3,
			colors: ['#999999', '#00b3b3','#ff8533']
        };

        var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_cost'));
        chart.draw(dataDonut_cost, optionsDonut_cost);
    }
	
	//Onroll Gender Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_onrollgen);

    function drawChartDonut_onrollgen() {
        var dataDonut_onrollgen = google.visualization.arrayToDataTable(data_onroll_gen);
			var optionsDonut_onrollgen = {
				pieHole: 0.2,
				colors: ['#999999', '#00b3b3']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_onrollgender'));
			chart.draw(dataDonut_onrollgen, optionsDonut_onrollgen);
    }
	
	//Trainee Gender Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_trngen);

    function drawChartDonut_trngen() {
        var dataDonut_trngen = google.visualization.arrayToDataTable(data_trn_gen);
			var optionsDonut_trngen = {
				pieHole: 0.2,
				colors: ['#999999', '#00b3b3']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_trngender'));
			chart.draw(dataDonut_trngen, optionsDonut_trngen);
    }
	
	//DMO Gender Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_dmogen);

    function drawChartDonut_dmogen() {
        var dataDonut_dmogen = google.visualization.arrayToDataTable(data_dmo_gen);
			var optionsDonut_dmogen = {
				pieHole: 0.2,
				colors: ['#999999', '#00b3b3']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_dmogender'));
			chart.draw(dataDonut_dmogen, optionsDonut_dmogen);
    }
	
	//ER & REG Gender Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_ergen);

    function drawChartDonut_ergen() {
        var dataDonut_ergen = google.visualization.arrayToDataTable(data_er_gen);
			var optionsDonut_ergen = {
				pieHole: 0.2,
				colors: ['#999999', '#00b3b3']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_ergender'));
			chart.draw(dataDonut_ergen, optionsDonut_ergen);
    }
	
	//FTC Gender Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_ftcgen);

    function drawChartDonut_ftcgen() {
        var dataDonut_ftcgen = google.visualization.arrayToDataTable(data_ftc_gen);
			var optionsDonut_ftcgen = {
				pieHole: 0.2,
				colors: ['#999999', '#00b3b3']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_ftcgender'));
			chart.draw(dataDonut_ftcgen, optionsDonut_ftcgen);
    }
	
	//VTC Gender Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_vtcgen);

    function drawChartDonut_vtcgen() {
        var dataDonut_vtcgen = google.visualization.arrayToDataTable(data_vtc_gen);
			var optionsDonut_vtcgen = {
				pieHole: 0.2,
				colors: ['#999999', '#00b3b3']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_vtcgender'));
			chart.draw(dataDonut_vtcgen, optionsDonut_vtcgen);
    }
	
	//Onroll Age Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_onrollage);

    function drawChartDonut_onrollage() {
        var dataDonut_onrollage = google.visualization.arrayToDataTable(data_onroll_age);
			var optionsDonut_onrollage = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_onrollage'));
			chart.draw(dataDonut_onrollage, optionsDonut_onrollage);
    }
	
	//Trainee Age Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_trnage);

    function drawChartDonut_trnage() {
        var dataDonut_trnage = google.visualization.arrayToDataTable(data_trainee_age);
			var optionsDonut_trnage = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_trnage'));
			chart.draw(dataDonut_trnage, optionsDonut_trnage);
    }
	
	//DMO Age Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_dmoage);

    function drawChartDonut_dmoage() {
        var dataDonut_dmoage = google.visualization.arrayToDataTable(data_dmo_age);
			var optionsDonut_dmoage = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_dmoage'));
			chart.draw(dataDonut_dmoage, optionsDonut_dmoage);
    }
	
	//ER & REG Age Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_erage);

    function drawChartDonut_erage() {
        var dataDonut_erage = google.visualization.arrayToDataTable(data_er_age);
			var optionsDonut_erage = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_erage'));
			chart.draw(dataDonut_erage, optionsDonut_erage);
    }
	
	//FTC Age Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_ftcage);

    function drawChartDonut_ftcage() {
        var dataDonut_ftcage = google.visualization.arrayToDataTable(data_ftc_age);
			var optionsDonut_ftcage = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_ftcage'));
			chart.draw(dataDonut_ftcage, optionsDonut_ftcage);
    }
	
	//VC Age Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_vcage);

    function drawChartDonut_vcage() {
        var dataDonut_vcage = google.visualization.arrayToDataTable(data_vc_age);
			var optionsDonut_vcage = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_vcage'));
			chart.draw(dataDonut_vcage, optionsDonut_vcage);
    }
	
	//Onroll Service Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_onrollser);

    function drawChartDonut_onrollser() {
        var dataDonut_onrollser = google.visualization.arrayToDataTable(data_onroll_ser);
			var optionsDonut_onrollser = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_onrollservce'));
			chart.draw(dataDonut_onrollser, optionsDonut_onrollser);
    }
	
	//Trainee Service Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_trnser);

    function drawChartDonut_trnser() {
        var dataDonut_trnser = google.visualization.arrayToDataTable(data_trn_ser);
			var optionsDonut_trnser = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_trnservce'));
			chart.draw(dataDonut_trnser, optionsDonut_trnser);
    }
	
	//DMO Service Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_dmoser);

    function drawChartDonut_dmoser() {
        var dataDonut_dmoser = google.visualization.arrayToDataTable(data_dmo_ser);
			var optionsDonut_dmoser = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_dmoservce'));
			chart.draw(dataDonut_dmoser, optionsDonut_dmoser);
    }
	
	//ER & REG Service Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_erser);

    function drawChartDonut_erser() {
        var dataDonut_erser = google.visualization.arrayToDataTable(data_er_ser);
			var optionsDonut_erser = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_erservce'));
			chart.draw(dataDonut_erser, optionsDonut_erser);
    }
	
	//FTC Service Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_ftcser);

    function drawChartDonut_ftcser() {
        var dataDonut_ftcser = google.visualization.arrayToDataTable(data_ftc_ser);
			var optionsDonut_ftcser = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_ftcservce'));
			chart.draw(dataDonut_ftcser, optionsDonut_ftcser);
    }
	
	//VC Service Count
	google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChartDonut_vcser);

    function drawChartDonut_vcser() {
        var dataDonut_vcser = google.visualization.arrayToDataTable(data_vc_ser);
			var optionsDonut_vcser = {
				pieHole: 0.3,
				colors: ['#a3a3c2', '#00e6ac','#ff9966', '#b3d9ff','#e62e00']
			};

			var chart = new google.visualization.PieChart(document.getElementById('chart_Donut_vcservce'));
			chart.draw(dataDonut_vcser, optionsDonut_vcser);
    }
});